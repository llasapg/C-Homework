﻿using System;
using System.Threading;
using System.Collections;
using System.Collections.Generic;
using Base_oop.Cars;
using Base_oop.Animals;
using Base_oop.Department;

namespace Base_oop
{
    class Program
    {
        static void Main(string[] args)
        {
            Car[] cars = new Car[3];
            for(int i = 0;i < cars.Length;i++)
            {
                cars[i] = new Car();
                cars[i].Input();
                cars[i].ChangePrice((cars[i].Price / 100 * 10) + cars[i].Price);
            }
            for(int i = 0;i < cars.Length;i++)
                cars[i].Print();
            string newColor = "red";
            for(int i = 0;i < cars.Length;i++)
                if(cars[i].Color == "white")
                    cars[i].Color = newColor;
            Thread.Sleep(1000);
            Console.WriteLine("_____________________________________");
            List<IAnimal> list = new List<IAnimal>();
            for(int i = 0;i< 5;i++)
            {
                list.Add(new Dog(){Name = $"Rex_{i}"});
                list.Add(new Cat(){Name = $"Garold_{i}"});
            }
            foreach(IAnimal an in list)
            {
                an.Voice();
                an.Feed();
            }
            Thread.Sleep(1000);
            Console.WriteLine("_____________________________________");
            Collection_Handler();
            Thread.Sleep(1000);
            Console.WriteLine("_____________________________________");
            try
            {
                Department_h.Name = "SoftServe";
                Manager m = new Manager("Vasua","Pupkin",1000,3);
                m.Team = new Person[]{new Designer("Lupa","Pupkin",750,2,m),
                new Developer("Pupa","Lupkin",1000,7,m)}; 
                Department_h.count.Add(m);
                Console.WriteLine($"Added new employee to the department - {Department_h.Name}");
                Console.WriteLine("Such as :");
                for(int i = 0; i < Department_h.count.Count;i++)
                {
                    Console.WriteLine((Department_h.count[i]).ToString());
                    Console.WriteLine("And his team : ");
                    Person[] pp = new Person[Department_h.count[i].Team.Length];
                    pp = Department_h.count[i].Team;
                    foreach(var item in pp)
                    {
                        Console.WriteLine(item.ToString());
                    }
                }
                Console.WriteLine("Giving to the all stuff painment : ");
                foreach(var p in Department_h.count)
                {
                    p.Get_Salary();
                }
                Console.WriteLine("_____________________________________");
                Thread.Sleep(1000);
                Console.WriteLine("Now lets add some extra workers : ");
                Manager manager = new Manager("Evgen","Gavrasienko",10000,25);
                Person[] team = new Person[]{
                new Developer("Sergey","Ivanov",999,2,manager),
                new Designer("Vladumir","Melnikov",1000,3,manager)};
                Department_h.AddTeamMembers(manager,team);
            }
            catch(SalaryGivingException ex)
            {
                Console.WriteLine($"Error - {ex.Message}");
            }
            catch(Exception ex)
            {
                Console.WriteLine($"Error - {ex.Message}");
            }
        }
        static void Collection_Handler()
        {
            Console.WriteLine("Please, enter 10 integer numbers (also try put -10)");
            ArrayList list = new ArrayList();
            string index_ten = "";
            for(int i = 0;i < 10;i++)
            {
                string text = Console.ReadLine();
                int x = Convert.ToInt32(text);
                list.Add(x);
                if(x == -10)
                    index_ten += i;
                else if((int)list[i] > 20)
                    list[i] = null;
            }
            Console.WriteLine($"[-10] was on positions : ");
            foreach(char item in index_ten)
            {
                
                Console.Write(item + " ");
            }
            Console.Write("\n");
            Console.WriteLine("After removing all numbers > 20 : ");
            foreach(var item in list)
            {
                if(item != null)
                    Console.Write(item + " ");
            }
            Console.WriteLine("\nAfter adding extra numbers and sorting : ");
            list[2] = 1;list[8] = -3;list[5] = -4;
            list.Sort();
            foreach(var item in list)
            {
                if(item != null)
                    Console.Write(item + " ");
            }
            Console.Write("\n");

            
        }
    }
    namespace Cars{
        public class Car{
        string brand;
        string color;
        double price;
        bool price_changed = false;
        public string Brand{
            get{return brand;}
            set{
                if(value != "")
                    brand = value;
                else
                {
                    Console.WriteLine("Input some brand");
                }
            }
        }
        public string Color{
            get{return brand;}
            set{
                if(value != "")
                    color = value;
                else
                {
                    Console.WriteLine("Input some color");
                }
            }
        }
        public double Price{
            get{return price;}
            set{
                if(value > 0)
                    price = value;
            }
        }
        public void Input()
        {
            Console.WriteLine("Please,enter car brand : ");
            string text = Console.ReadLine();
            Brand = text;
            Console.WriteLine("Please,enter car color : ");
            text = Console.ReadLine();
            Color = text;
            Console.WriteLine("Please,enter car price : ");
            text = Console.ReadLine();
            Price = Convert.ToDouble(text);
        }
        public void Print()
        {
            Console.WriteLine($"Your car brand is - {Brand}, color - {Color} and price is - {Price}");
            if(price_changed == true)
                Console.Write("!after price changed!\n");
        }
        public void ChangePrice(double newprice)
        {
            this.price_changed = true;
            this.price = newprice;
        }
    }
    }
    namespace Animals
    {
        interface IAnimal
    {
        string Name{get;set;}
        void Voice();
        void Feed();
    }
    class Dog : IAnimal
    {
        public string Name{get;set;}
        public virtual void Voice()
        {
            Console.WriteLine("Bark!!!");
        }
        public virtual void Feed()
        {
            Console.WriteLine($"Dog {this.Name} eats ...");
        }
    }
    class Cat : Dog
    {
        public override void Feed()
        {
            Console.WriteLine($"Cat {this.Name} eats fish...");
        }
        public override void Voice()
        {
            Console.WriteLine("Meaw");
        }
    }
    }
    namespace Department
    {
        class SalaryGivingException : Exception
        {
            public SalaryGivingException(string Message):base(Message)
            {

            }
        }
        static class Department_h{
            public static string Name{get;set;}
            public static List<Manager> count = new List<Manager>();
            public static void Get_Salary(this Manager manager)
            {
                if(manager.Team.Length < 1)
                    throw new SalaryGivingException("Mannager dont have a team!!!");
                else if(manager.Team.Length > 5)
                    manager.Salary = 1000 + 200;
                else if(manager.Team.Length > 10)
                    manager.Salary = 1000 + 300;
                else
                    manager.Salary += 1000;
                Console.WriteLine($"Manager {manager.Firstname} and all his team gets their salary");
            }
            public static void Get_Salary(this Developer dev)
            {
                dev.Salary += 1000;
                Console.WriteLine($"Developer {dev.Firstname} gets his salary");
            }
            public static void Get_Salary(this Designer des)
            {
                des.Salary += 1000;
                Console.WriteLine($"Designer {des.Firstname} gets his salary");
            }
            public static void AddTeamMembers(Manager m,Person[] p)
            {
                Manager manager = m;
                manager.Team = p;
                count.Add(manager);
                Console.WriteLine($"New manager - {manager.Firstname} with his team added in our department :");
                foreach(var item in p)
                {
                    Console.WriteLine(item.Firstname);
                }
            }
        }
        abstract class Person
        {
            protected double salary;
            public string Firstname{get;set;}
            public string Lastname{get;set;}
            public virtual double Salary{
                get{return salary;}
                set
                {   if(this.Experiance > 2)
                        salary = value + 200;
                    else if(this.Experiance > 5)
                        salary = value * 1.2 + 500;
                    }
                }
            public int Experiance{get;set;}
            public Person(string firstname,string lastname,double salary,int exp)
            {
                Firstname = firstname;
                Lastname = lastname;
                Salary = salary;
                Experiance = exp;
            }
            public override string ToString()
            {
                return $"Person - {Firstname} {Lastname}, experiance: {this.Experiance}";
            }
        }
        class Manager : Person{
            public Manager(string firstname,string lastname,double salary,int exp) : base(firstname,lastname,salary,exp)
            {
                
            }
            public Person[] Team{get;set;}
            public override double Salary{
                get{return salary;}
                set{
                    salary = value;
                }
            }
            public override string ToString()
            {
                return $"Manager - {Firstname} {Lastname}, experiance: {this.Experiance}";
            }
            public void AddToTeam(Person[] arr)
            {
                this.Team = arr;
            }
        }
        class Developer : Person{
            public Manager Boss{get;set;}
            public Developer(string firstname,string lastname,double salary,int exp,Manager boss) : base(firstname,lastname,salary,exp)
            {
                Boss = boss;
            }
            public override string ToString()
            {
                return $"{Firstname} {Lastname}, manager: {this.Boss.Firstname}, experiance: {this.Experiance}";
            }
        }
        class Designer : Person{
            public Manager Boss{get;set;}
            public sbyte Eff_Coef{get;set;}
            public Designer(string firstname,string lastname,double salary,int exp,Manager boss) : base(firstname,lastname,salary,exp)
            {
                Boss = boss;
            }
            public override string ToString()
            {
                return $"{Firstname} {Lastname}, manager: {this.Boss.Firstname}, experiance: {this.Experiance}";
            }
        }
    }

}
