﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace Ex_Files
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Creating files data.txt and rez.txt...");
            Thread.Sleep(1000);
            Console.WriteLine(Directory.GetCurrentDirectory());
            string pathfirst = Directory.GetCurrentDirectory() + "//data.txt";//Created files
            FileInfo filefirst = new FileInfo(pathfirst);
            if(!filefirst.Exists)
                filefirst.Create();
            string pathsecond = Directory.GetCurrentDirectory() + "//rez.txt";
            FileInfo filesecond = new FileInfo(pathsecond);
            if(!filesecond.Exists)
                filesecond.Create();
            try{
                Console.WriteLine("Please enter first and second double numbers : ");
                double first = 0;double second = 0;
                string text = Console.ReadLine();
                first = Convert.ToDouble(text);
                text = Console.ReadLine();
                second = Convert.ToDouble(text);
                Div(first,second);
                using(StreamWriter writer = new StreamWriter(pathfirst,false)){
                writer.WriteLine("Result of the operation is - " + Div(first,second));
                }
                string message = "";
                using(StreamReader reader = new StreamReader(pathfirst))
                {
                    message = reader.ReadToEnd();
                }
                using(StreamWriter writer = new StreamWriter(pathsecond,false))
                {
                writer.WriteLine(message);
                }//put result in our files
                Console.WriteLine("Result was moved to file rez.txt");
            }
            catch(DivExHandler ex)
            {
                Console.WriteLine($"Error - {ex.Message}");
            }
            catch(Exception ex)
            {
                Console.WriteLine($"Error - {ex.Message}");
            }
            Console.WriteLine("Work with files has ended");
            Console.WriteLine("_____________________________________");
            Dictionary<string,string> PhoneBook = new Dictionary<string,string>();
            string filepath = Directory.GetCurrentDirectory()+"//Phones.txt";
            FileInfo phonefile = new FileInfo(filepath);
            if(!phonefile.Exists)
                phonefile.Create();
            string[] names = new string[9]{"Oleg","Evgen","Igor","Dmitryi","Maksim","Ivan","Arsen","Artem","Rob"};
            using(StreamWriter writer = new StreamWriter(filepath,false))
            {
                for(int i = 0;i < 9;i++)
                {
                    Random Random = new Random();
                    int x=Random.Next(1, 9);
                    writer.WriteLine($"+8{x}3{x}5{x}9{x}81 : {names[i]}");
                }
            }
            Console.WriteLine("After reading from file Phonebook we get this values : ");
            using(StreamReader reader = new StreamReader(filepath,false))
            {
                for(int i = 0;i < 9;i++)
                {
                    string text = reader.ReadLine();
                    string sub1 = text.Substring(14);
                    string sub2 = text.Substring(0,11);
                    PhoneBook.Add(sub1,sub2);
                    Console.WriteLine(sub1 +" : "+ sub2);
                }
            }
            Console.WriteLine("_____________________________________");
            Console.WriteLine("Please enter the name of person, which number you want to know : ");
            string name = Console.ReadLine();
            bool finded = false;
            foreach(var item in PhoneBook)
            {
                if(item.Key == name)
                {
                finded=true;
                Console.WriteLine($"Its number of {name} - " + item.Value);
                }
            }
            if(!finded)
                Console.WriteLine("There werent such name in this phonebook");
            string filepathnext = Directory.GetCurrentDirectory() +"//next.txt";
            string[] textpro = new string[9];
            using(StreamReader reader = new StreamReader(filepath,false))
            {
                for(int i = 0;i < 9;i++)
                {
                    textpro[i]= reader.ReadLine();
                }
            }
            for(int i = 0;i < 9;i++)
            {
                textpro[i] = textpro[i].Replace("+8","+38");
            }
            using(StreamWriter writer = new StreamWriter(filepathnext,false))
            {
                for(int i = 0;i < 9;i++)
                {
                    string t = Convert.ToString(textpro[i]);
                    writer.WriteLine(t);
                }      
            }
        }
        static double Div(double first,double second)
        {
            if(second == 0)
                throw new DivExHandler("You cant divide by 0!!!");
            return first / second;
        }
        class DivExHandler:Exception
        {
            public DivExHandler(string message):base(message)
            {

            }
        }
    }
}
