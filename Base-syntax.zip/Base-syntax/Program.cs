﻿using System;
using System.Linq;
using System.Text;

namespace Base_syntax
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Base_syntax task");
            Console.WriteLine("________________________________");
            int[] arr = new int[10]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
            Console.WriteLine("Sum result - " + Sum(arr));//55
            Console.WriteLine("________________________________");
            Console.WriteLine("Multiply result - " + Multiply(arr));//36288000
            Console.WriteLine("________________________________");
            Console.WriteLine("Reverse result - " + Reverse("Test message"));
            Console.WriteLine("________________________________");
            Console.WriteLine("Is_Palindrome result - " + Is_Palindrome("YesseY"));
            Console.WriteLine("________________________________");
            Console.WriteLine("Histogram : ");
            Histogram(1,2,3);
            Console.WriteLine("\n________________________________");
            Console.WriteLine("Caesar_Cipher result - " + Caesar_Cipher("Privet", 1));
            Console.WriteLine("________________________________");
            Console.WriteLine("Please enter count of ROWS and COLS : ");
            int Rows = 0;int Cols = 0;
            Converter(ref Rows,ref Cols);
            int[,] array = new int[Rows,Cols];
            Console.WriteLine("________________________________");
            Diagonal_Reverse(array,Rows,Cols);
            Console.WriteLine("________________________________");
            int from =0;int to = 0;
            Game_Param(ref from,ref to);
            Console.WriteLine("Started GAME method");
            Game(from,to);
            Bracket_Habdler("[[[][][][[][[]");
            Console.WriteLine("________________________________");
            char_freq("jsksurteddde");
            Console.WriteLine("________________________________");
            dec_to_bin(150);

        }
        static  void Game_Param(ref int from,ref int to)
        {
            Console.WriteLine("Please, enter the number from which to start generating a random number :");
            string text = Console.ReadLine();
            from = Convert.ToInt32(text);
            Console.WriteLine("Please, enter the number to which to generate a random number :");
            text = Console.ReadLine();
            to = Convert.ToInt32(text);
        }
        static void Converter(ref int Rows,ref int Cols)
        {
            string text = Console.ReadLine();
            Rows = Convert.ToInt32(text);
            text = Console.ReadLine();
            Cols = Convert.ToInt32(text);
        }
        static void FirstMethod(string name)
        {
            Console.WriteLine($"Hello {name}");
        }
        static int Sum(int[] array)
        {
            int sum =0;
            for(int i = 0;i < array.Length;i++)
                sum+=array[i];
            return sum;
        }
        static int Multiply(int[] array)
        {
            int mult = 1;
            for(int i = 0;i < array.Length;i++)
                mult*=array[i];
            return mult;
        }
        static string Reverse(string text)
        {
            string output = new string(text.ToCharArray().Reverse().ToArray());
            return output;
        }
        static bool Is_Palindrome(string word)
        {
            word.ToLower();
            string first = word.Substring(0, word.Length / 2);
            char[] arr   = word.ToCharArray();
            Array.Reverse(arr);
            string temp   = new string(arr);
            string second = temp.Substring(0, temp.Length / 2);
            return first.Equals(second);
        }
        static void Histogram(int x, int y, int z)
        {
            for(int i = 0;i < x;i++)
                Console.Write("*");
            Console.Write("\n");
            for(int i = 0;i < y;i++)
                Console.Write("*");
             Console.Write("\n");
            for(int i = 0;i < z;i++)
                Console.Write("*");
        }
        static string Caesar_Cipher(string message, int key)
        {
            string result = "";
            string alf = "abcdefghijklmnopqrstuvwxyz";
            message.ToLower();
            for(int i = 0;i < message.Length;i++)
            {
                int k = alf.IndexOf(message[i]);
                k += key;
                result += alf[k];
            }
            return result;
        }
        static void Diagonal_Reverse(int[,] arr,int Rows,int Cols)
        {
            int x = 1;
            for(int i = 0;i < Rows;i++)
            {
                for(int j = 0;j < Cols;j++)
                {
                    arr[i,j] = x;
                    x++;
                }
            }
            Console.WriteLine("Current matrix : ");
            for(int i = 0;i < Rows;i++)
            {
                for(int j = 0;j < Cols;j++)
                {
                    Console.Write(arr[i,j] + " ");
                }
                Console.Write("\n");
            }
            Console.WriteLine("New matrix : ");
            for(int i = 0;i < Rows;i++)
            {
                for(int j = 0;j < Cols;j++)
                {
                    Console.Write(arr[j,i] + " ");
                }
                Console.Write("\n");
            }
        }
        static void Game(int from,int to)
        {
            Console.WriteLine("Try to guess secret number : ");
            Random random = new Random();
            int secret_answer = random.Next(from,to);
            for(int i = 0;i < 100;i++)
            {
                string text = Console.ReadLine();
                int x = Convert.ToInt32(text);
                if(x == secret_answer)
                {
                    Console.WriteLine("Great!!! Your answer is correct!!!");
                    return;
                }
                else
                Console.WriteLine("Try again");
            }
        }
        static void Bracket_Habdler(string message)
        {
            int j = 0;int counter = 0;
            Console.WriteLine("All of closed brakets in this message - ");
            for(int i = 0;i < message.Length;i++)
            {
                if(j <= i)
                {
                    j++;
                    if((message[i] == '[' && message[j] == ']'))
                    {
                        Console.Write($"{message[i]}{message[j]}");
                        counter++;
                    }
                    
                }
            }
            Console.WriteLine($"   Total count - {counter}  ");
        }
        //////////////DODELAT!!!////////////////////
        static void char_freq(string message)
        {
            string alf = "abcdefghijklmnopqrstuvwxyzzyxwvutsrqponmlkjihgfedcba";
            string result = "";
            for(int i = 0;i < message.Length;i++)
                for(int j = 0;j < message.Length;j++)
                    if(message[i]== alf[j])
                        result += j;

            int count = 0;int[] x = new int[result.Length];
            for(int i =0;i < x.Length;i++)
            {
                x[i] = Convert.ToInt32(result[i]);
            }
            for(int j = 0;j < result.Length;j++)
            {
                int y = Convert.ToInt32(result[j]);
                if(x[j] == y)
                    count++;
            }
                for(int i =0;i < x.Length;i++)
                {
                    int o = x[i];
                    if(o < x.Length)
                        Console.WriteLine($"Each letter from this string  is - {alf[o]} and its count - {count}");
                    //I need to get symbols from Unicode code. I dont know how to transform it.
                }
        }
        static void dec_to_bin(int x)
        {
            int base_v = x;
            string result = "";
            while(x >= 1)
            {
                result += x % 2;
                x /= 2;
            }
            Console.WriteLine($"{base_v} in binary system - " + Reverse(result));
        }
    }
}
